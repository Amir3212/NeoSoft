package com.amir.neosofttest.model

data class UserModel(
    val name: String,
    val id: Int,
    val email: String,
    val image: String,
)
