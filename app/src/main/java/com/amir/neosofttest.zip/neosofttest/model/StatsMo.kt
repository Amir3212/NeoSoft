package com.amir.neosofttest.model

data class StatsMo(
    val ch: String,
    val count: Int,
)